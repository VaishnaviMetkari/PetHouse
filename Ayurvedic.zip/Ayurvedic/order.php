<?php
session_start();
include('../includes/db_connect.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: user/login.php');
    exit();
}

if (isset($_POST['place_order'])) {
    $user_id = $_SESSION['user_id'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $payment_method = $_POST['payment_method'];

    // Get products from the cart
    $stmt = $conn->prepare("SELECT * FROM carts WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $cart_items = $stmt->get_result();

    while ($cart_item = $cart_items->fetch_assoc()) {
        $product_id = $cart_item['product_id'];
        $quantity = $cart_item['quantity'];

        $order_stmt = $conn->prepare("INSERT INTO orders (user_id, product_id, quantity, name, address, payment_method) VALUES (?, ?, ?, ?, ?, ?)");
        $order_stmt->bind_param("iiisss", $user_id, $product_id, $quantity, $name, $address, $payment_method);
        $order_stmt->execute();
    }

    // Clear the cart after placing the order
    $stmt = $conn->prepare("DELETE FROM carts WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();

    echo "<p style='color: green;'>Order placed successfully!</p>";

    $stmt->close();
    $conn->close();
}
?>
