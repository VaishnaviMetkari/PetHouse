<?php
include('includes/db_connect.php');  // Database connection
include('includes/header.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet shop</title>
    <style>
        /* General styling */
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            margin-top: 80px;
        }

        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        a {
            text-decoration: none;
            color: #fff;
        }

        /* Search form styling */
        form.d-flex {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .search-inp {
            width: 300px;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .btn-search {
            padding: 10px 20px;
            margin-left: 10px;
            background-color: #28a745;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-search:hover {
            background-color: #218838;
        }

        /* Category filter styling */
        .category-filter {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .category-select {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-right: 10px;
        }

        .btn-filter {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-filter:hover {
            background-color: #0056b3;
        }

        /* Add product button styling */
        .add-product-btn {
            display: block;
            text-align: center;
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            margin: 10px auto;
            width: 150px;
            transition: background-color 0.3s;
        }

        .add-product-btn:hover {
            background-color: #0056b3;
        }

        /* Products grid */
        .products {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
        }

        /* Product card styling */
        .product-card {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 20px;
            width: 300px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: box-shadow 0.3s ease;
            text-align: center;
        }

        .product-card:hover {
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .product-card img {
            width: 100%;
            height: auto;
            border-radius: 10px;
            margin-bottom: 15px;
        }

        .product-card h3 {
            font-size: 20px;
            margin: 10px 0;
        }

        .product-card p {
            color: #555;
            font-size: 16px;
            margin: 10px 0;
        }

        .product-card a {
            display: inline-block;
            padding: 8px 20px;
            background-color: #28a745;
            color: white;
            border-radius: 5px;
            margin-top: 10px;
            transition: background-color 0.3s ease;
        }

        .product-card a:hover {
            background-color: #218838;
        }

        /* Responsive design */
        @media (max-width: 768px) {
            .product-card {
                width: 100%;
            }

            form.d-flex {
                flex-direction: column;
                align-items: center;
            }

            .search-inp {
                width: 80%;
            }

            .btn-search {
                margin-left: 0;
                margin-top: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Our Products</h2>
        <div class="category-filter">
            <select class="category-select" name="category" id="category">
                <option value="">All Categories</option>
                <option value="Dog Food">Dog Food</option>
                <option value="Cat Food">Cat Food</option>
                <option value="Fish Food">Fish Food</option>
                <option value="Accessories">Accessories</option>
            </select>
            <button class="btn-filter" onclick="filterProducts()">Filter</button>
        </div>
        <div>
            <form class="d-flex" action="/Ayurvedic/product.php" method="GET">
                <input class="form-control me-2 search-inp" type="search" placeholder="Search Product" aria-label="Search" name="query">
                <button class="btn btn-search" type="submit">Search</button>
            </form>
        </div>
        <a href="admin/add_product.php" class="add-product-btn">Add Product</a>
        <div class="products">
            <?php
            // Get the search query and category from the URL
            $searchQuery = isset($_GET['query']) ? trim($_GET['query']) : '';
            $category = isset($_GET['category']) ? trim($_GET['category']) : '';

            // Build the SQL query based on search and category
            $query = "SELECT * FROM products WHERE 1=1";

            // Add search condition
            if ($searchQuery) {
                $searchQuery = mysqli_real_escape_string($conn, $searchQuery);
                $query .= " AND (name LIKE '%$searchQuery%' OR description LIKE '%$searchQuery%')";
            }

            // Add category condition to check if the category is mentioned in the description
            if ($category) {
                $category = mysqli_real_escape_string($conn, $category);
                $query .= " AND (category = '$category' OR description LIKE '%$category%')";
            }

            // Check if connection is established
            if (!$conn) {
                echo "Database connection failed!";
            } else {
                // Execute the query
                $result = mysqli_query($conn, $query);
                if ($result && mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)): ?>
                        <div class="product-card">
                            <img src="assets/images/<?php echo $row['image']; ?>" alt="<?php echo $row['name']; ?>">
                            <h3><?php echo $row['name']; ?></h3>
                            <p><?php echo $row['description']; ?></p>
                            <p>Price: <?php echo $row['price']; ?> INR</p>
                            <a href="view_product.php?id=<?php echo $row['id']; ?>">View Details</a>
                            <a href="cart.php?action=add&id=<?php echo $row['id']; ?>" class="btn-add-to-cart">Add to Cart</a>
                        </div>
                    <?php endwhile;
                } else {
                    echo "<p>No products found for your search query.</p>";
                }
            }
            ?>
        </div>
    </div>

    <script>
        function filterProducts() {
            const category = document.getElementById('category').value;
            const searchQuery = document.querySelector('input[name="query"]').value;
            let url = '/Ayurvedic/product.php?';

            if (searchQuery) {
                url += 'query=' + encodeURIComponent(searchQuery) + '&';
            }

            if (category) {
                url += 'category=' + encodeURIComponent(category);
            }

            window.location.href = url;
        }
    </script>

    <?php include('includes/footer.php'); ?>
</body>
</html>
``
