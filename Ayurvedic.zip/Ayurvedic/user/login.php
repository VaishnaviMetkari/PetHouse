<?php
session_start();

// Include the database connection file
include('../includes/db_connect.php');

// Enable error reporting to catch issues
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Handle login
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // Prepare SQL statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $user['password'])) {
            // Set session variables
            $_SESSION['user'] = $user['username'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_id'] = $user['id'];

            // Redirect to homepage
            header('Location: ../index.php');
            exit();
        } else {
            echo "<p style='color: red;'>Invalid login credentials</p>";
        }
    } else {
        echo "<p style='color: red;'>No user found with this email</p>";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();
}

// Handle password reset submission
if (isset($_POST['reset_password'])) {
    $email = $_POST['reset_email'];
    
    // Check if the email exists in the database
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Show the new password fields
        $showNewPasswordFields = true;
    } else {
        echo "<p style='color: red;'>No user found with this email</p>";
    }

    // Close statement
    $stmt->close();
}

// Handle new password submission
if (isset($_POST['submit_new_password'])) {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    $email = $_POST['reset_email']; // Use the email entered for reset

    // Check if passwords match
    if ($new_password === $confirm_password) {
        // Hash the new password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        
        // Update the password in the database
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $stmt->bind_param("ss", $hashed_password, $email);
        if ($stmt->execute()) {
            echo "<p style='color: green;'>Password has been updated successfully. You can now login.</p>";
        } else {
            echo "<p style='color: red;'>Error updating password.</p>";
        }

        // Close statement
        $stmt->close();
    } else {
        echo "<p style='color: red;'>Passwords do not match.</p>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        h1 {
            margin-bottom: 20px;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #5cb85c;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
        p {
            margin-top: 20px;
            text-align: center;
        }
        a {
            color: #5cb85c;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
        .reset-container {
            margin-top: 20px;
            display: none; /* Initially hidden */
        }
        #new-password-container {
            display: none; /* Hide the new password fields by default */
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Login</h1>
   
    <form method="post" action="login.php">
        <label for="email">Email:</label>
        <input type="email" name="email" required>

        <label for="password">Password:</label>
        <input type="password" name="password" required>

        <input type="submit" name="login" value="Login">
    </form>

    <p>Don't have an account? <a href="signup.php">Sign up here</a>.</p>
    <p><a href="#" id="forgot-password-link">Forgot Password?</a></p>

    <div class="reset-container" id="reset-container">
        <h2>Reset Password</h2>
        <form method="post" action="login.php">
            <label for="reset_email">Enter your email:</label>
            <input type="email" name="reset_email" required>
            <input type="submit" name="reset_password" value="Reset Password">
        </form>
    </div>

    <div id="new-password-container">
        <h2>Set New Password</h2>
        <form method="post" action="login.php">
            <input type="hidden" name="reset_email" value="<?php echo isset($email) ? $email : ''; ?>">
            <label for="new_password">New Password:</label>
            <input type="password" name="new_password" required>
            
            <label for="confirm_password">Confirm Password:</label>
            <input type="password" name="confirm_password" required>
            
            <input type="submit" name="submit_new_password" value="Update Password">
        </form>
    </div>
</div>

<script>
    // JavaScript to toggle the reset password form and new password fields
    document.getElementById('forgot-password-link').onclick = function(event) {
        event.preventDefault(); // Prevent default anchor behavior
        var resetContainer = document.getElementById('reset-container');
        resetContainer.style.display = resetContainer.style.display === 'none' ? 'block' : 'block';
    };
    
    // Optional: Show new password fields if user exists
    <?php if (isset($showNewPasswordFields) && $showNewPasswordFields): ?>
        document.getElementById('new-password-container').style.display = 'block';
    <?php endif; ?>
</script>
</body>
</html>
