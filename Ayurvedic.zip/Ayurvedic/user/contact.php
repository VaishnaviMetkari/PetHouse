<!--  SYD37MJMBL6MF2XEJ8W467MY -->

<!-- API KEY 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 -->

<?php
// Include the SendGrid autoloader
require '../vendor/autoload.php';  // This path should now work after moving the folder

// Initialize success and error messages
$successMessage = '';
$errorMessage = '';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Create a new SendGrid Mail instance
    $emailToSend = new \SendGrid\Mail\Mail();
    $emailToSend->setFrom("aishwrya13868@gmail.com", "Aishwarya Thorat"); // Replace with your email and name
    $emailToSend->setSubject("Contact Form Submission from $name");
    $emailToSend->addTo("kiraa5566@gmail.com", "Aish"); // Replace with the recipient's email and name
    $emailToSend->addContent(
        "text/html", 
        "<h1>Contact Form Submission</h1>
        <p><strong>Name:</strong> {$name}</p>
        <p><strong>Email:</strong> {$email}</p>
        <p><strong>Message:</strong><br>{$message}</p>"
    );

    try {
        // Send the email using the SendGrid API
        $sendgrid = new \SendGrid('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'); // Your SendGrid API Key
        $response = $sendgrid->send($emailToSend);

        if ($response->statusCode() == 202) {
            $successMessage = "Message has been sent successfully!";
        } else {
            $errorMessage = "Message could not be sent. Error: " . $response->body();
        }
        
    } catch (Exception $e) {
        $errorMessage = "Message could not be sent. Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #87CEEB; /* Sky blue background */
            color: #333;
        }
        .contact-form {
            background: rgba(255, 255, 255, 0.8);
            padding: 30px;
            border-radius: 10px;
            margin-top: 50px;
        }
        .contact-form h2 {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 contact-form">
            <h2>Contact Us</h2>
            <!-- Display success or error message -->
            <?php if (!empty($successMessage)): ?>
                <div class="alert alert-success"><?= $successMessage; ?></div>
            <?php endif; ?>
            <?php if (!empty($errorMessage)): ?>
                <div class="alert alert-danger"><?= $errorMessage; ?></div>
            <?php endif; ?>
            
            <!-- Contact Form -->
            <form method="POST" action="">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea class="form-control" id="message" name="message" rows="4" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
