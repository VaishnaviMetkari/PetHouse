<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Pet Shop</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <style>
        body {
            background-color: #87CEEB; /* Sky blue background */
            color: #333;
        }
        .about-section {
            background: rgba(255, 255, 255, 0.9);
            padding: 40px;
            border-radius: 10px;
            margin-top: 50px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .about-section h2 {
            margin-bottom: 20px;
            font-size: 3vw; /* Adjust heading size based on screen width */
        }
        .about-section p {
            font-size: 1.2vw; /* Responsive text size */
            line-height: 1.6;
        }
        .image-container {
            text-align: center;
            margin-bottom: 30px;
        }
        .image-container img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }

        /* Responsive design for smaller screens */
        @media (max-width: 768px) {
            .about-section h2 {
                font-size: 6vw; /* Larger font on small screens */
            }
            .about-section p {
                font-size: 3.5vw;
            }
            .about-section {
                padding: 20px;
            }
        }

        @media (max-width: 576px) {
            .about-section h2 {
                font-size: 7vw; /* Even larger for very small screens */
            }
            .about-section p {
                font-size: 4vw;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 about-section">
            <div class="image-container">
                <!-- Image -->
                <img src="../assets/images/hero-banner.jpg" alt="Pet Shop" class="col-md-6">
            </div>
            <h2>About Us</h2>
            <p>Welcome to our Pet Shop! We are passionate about providing the best care for your beloved pets. Our shop is dedicated to offering a wide variety of pets and high-quality pet products to ensure a happy and healthy life for your furry friends.</p>

            <p>At our Pet Shop, we understand that pets are not just animals; they are family. That’s why we take pride in sourcing our pets from reputable breeders and offering a diverse range of animals, including dogs, cats, birds, fish, and small mammals. We believe that every pet deserves a loving home, and we are here to help you find your perfect companion.</p>

            <p>In addition to pets, we offer a vast selection of pet food, toys, and accessories. Our knowledgeable staff is always ready to assist you in choosing the right products for your pet's needs. We also provide grooming services to keep your pets looking their best.</p>

            <p>We believe in building a community of pet lovers. Join us for events, workshops, and pet adoption drives. Together, we can create a better world for our pets.</p>

            <p>Thank you for choosing our Pet Shop. We look forward to serving you and your furry companions!</p>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</body>
</html>
