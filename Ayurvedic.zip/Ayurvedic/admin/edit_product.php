<?php
session_start();
include('../includes/db_connect.php');

// Check if the user is logged in and has the role of admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    echo "<p style='color: red;'>You are not an admin! Access denied.</p>";
    echo '<p><a href="../product.php">Back to Home</a></p>';
    exit();
}

// Check if the product ID is passed via GET
if (isset($_GET['id'])) {
    $product_id = intval($_GET['id']);

    // Fetch the product details from the database
    $query = "SELECT * FROM products WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the product exists
    if ($result->num_rows > 0) {
        $product = $result->fetch_assoc();
    } else {
        echo "<p style='color: red;'>Product not found.</p>";
        echo '<p><a href="../product.php">Back to Home</a></p>';
        exit();
    }
} else {
    echo "<p style='color: red;'>No product ID provided.</p>";
    echo '<p><a href="../product.php">Back to Home</a></p>';
    exit();
}

// Handle the form submission to update the product
if (isset($_POST['edit_product'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);

    // Handle file upload (if a new image is uploaded)
    if (!empty($_FILES['image']['name'])) {
        $image = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];
        $target_directory = "../assets/images/";
        $target_file = $target_directory . basename($image);

        // Validate file type (allow only jpg, jpeg, png)
        $allowed_extensions = ['jpg', 'jpeg', 'png'];
        $file_extension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        if (!in_array($file_extension, $allowed_extensions)) {
            echo "<p style='color: red;'>Error: Invalid file format. Only JPG, JPEG, and PNG files are allowed.</p>";
            exit();
        }

        // Move the uploaded file
        if (move_uploaded_file($image_tmp, $target_file)) {
            $image_query = ", image='$image'";
        } else {
            echo "<p style='color: red;'>Error: Failed to upload the new image.</p>";
            exit();
        }
    } else {
        $image_query = ''; // Keep the existing image if no new one is uploaded
    }

    // Update the product details in the database
    $query = "UPDATE products SET name='$name', description='$description', price='$price' $image_query WHERE id='$product_id'";
    
    if (mysqli_query($conn, $query)) {
        echo "<p style='color: green;'>Product updated successfully.</p>";
        echo '<p><a href="../product.php">Back to Home</a></p>';
    } else {
        echo "<p style='color: red;'>Error: " . mysqli_error($conn) . "</p>";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            font-size: 2em;
            margin-bottom: 20px;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        input[type="text"], textarea, input[type="number"], input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #5cb85c;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Product</h1>
        <form method="post" action="edit_product.php?id=<?php echo $product_id; ?>" enctype="multipart/form-data">

            <label for="name">Product Name:</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>

            <label for="description">Description:</label>
            <textarea name="description" rows="4" required><?php echo htmlspecialchars($product['description']); ?></textarea>

            <label for="price">Price:</label>
            <input type="number" name="price" step="0.01" value="<?php echo htmlspecialchars($product['price']); ?>" required>

            <label for="image">Image:</label>
            <input type="file" name="image">

            <input type="submit" name="edit_product" value="Update Product">
        </form>
    </div>
</body>
</html>
