<?php
session_start();
include('../includes/db_connect.php');

// Check if the user is logged in and has the role of admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    echo "<p style='color: red;'>You are not an admin! Access denied.</p>";
    echo '<p><a href="../product.php">Back to Home</a></p>'; 
    exit();
}

if (isset($_GET['id'])) {
    $product_id = mysqli_real_escape_string($conn, $_GET['id']);
    
    // Fetch the product details to get the image file name
    $query = "SELECT image FROM products WHERE id = '$product_id'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) > 0) {
        $product = mysqli_fetch_assoc($result);
        $image = $product['image'];

        // Delete the product from the database
        $delete_query = "DELETE FROM products WHERE id = '$product_id'";
        if (mysqli_query($conn, $delete_query)) {
            // Remove the image file from the server
            $image_path = "../assets/images/" . $image;
            if (file_exists($image_path)) {
                unlink($image_path);
            }

            // Redirect to index.php after success
            header("Location: ../product.php");
            exit();
        } else {
            echo "<p style='color: red;'>Error: " . mysqli_error($conn) . "</p>";
        }
    } else {
        echo "<p style='color: red;'>Error: Product not found.</p>";
    }
} else {
    echo "<p style='color: red;'>Error: No product ID specified.</p>";
}
?>
