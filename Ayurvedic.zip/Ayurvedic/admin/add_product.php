<?php
session_start();
include('../includes/db_connect.php');

// Check if the user is logged in and has the role of admin
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] !== 'admin') {
    echo "<p style='color: red;'>You are not an admin! Access denied.</p>";
    echo '<p><a href="../product.php">Back to Home</a></p>'; 
    exit();
}

if (isset($_POST['add_product'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);

    // Handling file upload
    $image = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];
    $target_directory = "../assets/images/";
    $target_file = $target_directory . basename($image);

    // Check if the target directory exists
    if (!is_dir($target_directory)) {
        mkdir($target_directory, 0777, true);
    }

    // Validate the file type (only allow jpg, jpeg, png)
    $allowed_extensions = ['jpg', 'jpeg', 'png'];
    $file_extension = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    
    if (!in_array($file_extension, $allowed_extensions)) {
        echo "<p style='color: red;'>Error: Invalid file format. Only JPG, JPEG, and PNG files are allowed.</p>";
        exit();
    }

    // Attempt to move the uploaded file to the target directory
    if (move_uploaded_file($image_tmp, $target_file)) {
        // Insert product details into the database
        $query = "INSERT INTO products (name, description, price, image) VALUES ('$name', '$description', '$price', '$image')";
        if (mysqli_query($conn, $query)) {
            // Redirect to index.php after success
            header("Location: ../product.php");
            exit();
        } else {
            echo "<p style='color: red;'>Error: " . mysqli_error($conn) . "</p>";
        }
    } else {
        echo "<p style='color: red;'>Error: Failed to move uploaded file.</p>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            font-size: 2em;
            margin-bottom: 20px;
            color: #333;
        }
        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }
        input[type="text"], textarea, input[type="number"], input[type="file"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 4px;
            background-color: #5cb85c;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #4cae4c;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Add Product</h1>
        <form method="post" action="add_product.php" enctype="multipart/form-data">
            <label for="name">Product Name:</label>
            <input type="text" name="name" required>

            <label for="description">Description:</label>
            <textarea name="description" rows="4" required></textarea>

            <label for="price">Price:</label>
            <input type="number" name="price" step="0.01" required>

            <label for="image">Image:</label>
            <input type="file" name="image" required>

            <input type="submit" name="add_product" value="Add Product">
        </form>
    </div>
</body>
</html>
