<?php
ob_start(); 
include('includes/db_connect.php');
include('includes/header.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Get product ID
$product_id = $_GET['id'];

// Fetch the product details
$query = "SELECT * FROM products WHERE id = $product_id";
$result = mysqli_query($conn, $query);
$product = mysqli_fetch_assoc($result);

// Fetch existing reviews for the product, including the username of the reviewer
$reviews_query = "SELECT r.*, u.username AS author_name 
                  FROM reviews r 
                  JOIN users u ON r.user_id = u.id 
                  WHERE r.product_id = $product_id 
                  ORDER BY r.created_at DESC";
$reviews_result = mysqli_query($conn, $reviews_query);

// Handle review submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Escape inputs and ensure they are properly set
    $review_text = mysqli_real_escape_string($conn, $_POST['review_text']);
    $rating = (int)$_POST['rating']; // Cast rating to integer

    // Check if the user is logged in
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id']; // Assuming user ID is stored in session

        // Insert query to add the review
        $insert_review_query = "INSERT INTO reviews (product_id, user_id, review_text, rating, created_at)
                                VALUES ($product_id, $user_id, '$review_text', $rating, NOW())";

        // Execute the query and check for errors
        if (mysqli_query($conn, $insert_review_query)) {
            echo "<script>alert('Review submitted successfully.');</script>";
            // Optionally, redirect to the same page to avoid form resubmission
            header("Location: view_product.php?id=$product_id");
            exit;
        } else {
            die('Error: ' . mysqli_error($conn));
        }
    } else {
        // User is not logged in
        echo "<script>alert('You must be logged in to submit a review.');</script>";
    }
}

// Handle review deletion
if (isset($_GET['delete_review_id'])) {
    $review_id = $_GET['delete_review_id'];
    
    // Check if the logged-in user is the author of the review
    $check_author_query = "SELECT user_id FROM reviews WHERE id = $review_id";
    $author_result = mysqli_query($conn, $check_author_query);
    
    if ($author_result && mysqli_num_rows($author_result) > 0) {
        $author_data = mysqli_fetch_assoc($author_result);
        if ($author_data['user_id'] == $_SESSION['user_id']) {
            // Delete review if the user is the author
            $delete_review_query = "DELETE FROM reviews WHERE id = $review_id";
            mysqli_query($conn, $delete_review_query);
            echo "<script>alert('Review deleted successfully.');</script>";
            header("Location: view_product.php?id=$product_id");
            exit;
        } else {
            echo "<script>alert('You are not authorized to delete this review.');</script>";
        }
    } else {
        echo "<script>alert('Review not found.');</script>";
    }
}
ob_start(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">
    <title><?php echo htmlspecialchars($product['name']); ?> - Pet's House</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin-top: 150px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        #title {
            text-align: center;
            margin-top: 15px;
            font-size: 2em;
            margin-bottom: 20px;
            color: #333;
            font-weight: bold;
        }
        .image-container {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }
        p {
            font-size: 1.2em;
            margin-bottom: 10px;
            color: #555;
        }
        .price {
            font-size: 1.5em;
            color: #333;
            font-weight: bold;
        }
        .button-container {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        a {
            display: inline-block;
            padding: 10px 20px;
            font-size: 1.2em;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        a.add-to-cart {
            background-color: #007bff;
        }
        a.add-to-cart:hover {
            background-color: #0056b3;
        }
        a.edit-btn {
            background-color: #28a745;
        }
        a.edit-btn:hover {
            background-color: #218838;
        }
        a.delete-btn {
            background-color: #dc3545;
        }
        a.delete-btn:hover {
            background-color: #c82333;
        }
        .review-section {
            margin-top: 30px;
        }
        .review {
            border: 1px solid #ddd;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            background-color: #f9f9f9;
            transition: background-color 0.3s;
        }
        .review:hover {
            background-color: #f1f1f1; /* Lighter background on hover */
        }
        .review-rating {
            font-weight: bold;
            color: #ffcc00; /* Color for stars */
        }
        /* Styling for the review form */
        form {
            margin-bottom: 20px;
            background-color: #e9ecef;
            padding: 15px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            resize: vertical;
            margin-bottom: 10px;
        }
        button {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        /* Rating selection style */
        .rating-container {
            display: flex;
            justify-content: center;
            margin-bottom: 10px;
        }
        .rating-container input {
            display: none;
        }
        .rating-container label {
            font-size: 2em;
            color: #ccc; /* Default star color */
            cursor: pointer;
            margin: 0 5px;
        }
        .rating-container input:checked ~ label {
            color: #ffcc00; /* Selected star color */
        }
        .rating-container label:hover,
        .rating-container label:hover ~ label {
            color: #ffcc00; /* Hover star color */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 id="title"><?php echo htmlspecialchars($product['name']); ?></h1>
        
        <div class="image-container">
            <img src="assets/images/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
        </div>

        <p><?php echo htmlspecialchars($product['description']); ?></p>
        <p class="price">Price: &#x20B9; <?php echo htmlspecialchars($product['price']); ?></p>

        <div class="button-container">
            <a class="add-to-cart" href="cart.php?action=add&id=<?php echo $product_id; ?>">Add to Cart</a>
            <a class="edit-btn" href="admin/edit_product.php?id=<?php echo $product_id; ?>">Edit Product</a>
            <a class="delete-btn" href="admin/delete_product.php?id=<?php echo $product_id; ?>" onclick="return confirm('Are you sure you want to delete this product?');">Delete Product</a>
        </div>

        <div class="review-section">
            <h2>Reviews</h2>
            <?php while ($review = mysqli_fetch_assoc($reviews_result)): ?>
                <div class="review">
                    <div class="review-rating">
                        <?php echo str_repeat('★', $review['rating']); // Display filled stars ?>
                        <?php echo str_repeat('☆', 5 - $review['rating']); // Display empty stars ?>
                    </div>
                    <p><strong><?php echo htmlspecialchars($review['author_name']); ?></strong> <em>(<?php echo date('F j, Y', strtotime($review['created_at'])); ?>)</em></p>
                    <p><?php echo htmlspecialchars($review['review_text']); ?></p>
                    <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] == $review['user_id']): ?>
                        <a class="delete-btn" href="view_product.php?id=<?php echo $product_id; ?>&delete_review_id=<?php echo $review['id']; ?>" onclick="return confirm('Are you sure you want to delete this review?');">Delete Review</a>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        </div>

        <!-- Review Submission Form -->
        <h2>Submit Your Review</h2>
        <form method="post">
            <div class="rating-container">
                <input type="radio" id="star5" name="rating" value="5" required>
                <label for="star5">★</label>
                <input type="radio" id="star4" name="rating" value="4" required>
                <label for="star4">★</label>
                <input type="radio" id="star3" name="rating" value="3" required>
                <label for="star3">★</label>
                <input type="radio" id="star2" name="rating" value="2" required>
                <label for="star2">★</label>
                <input type="radio" id="star1" name="rating" value="1" required>
                <label for="star1">★</label>
            </div>
            <textarea name="review_text" rows="4" placeholder="Write your review here..." required></textarea>
            <button type="submit">Submit Review</button>
        </form>
    </div>
</body>
</html>
