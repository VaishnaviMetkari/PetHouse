<?php
include('includes/db_connect.php');
include('includes/header.php');
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: user/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Checkout logic
if (isset($_POST['checkout'])) {
    // Process the order by inserting into 'orders' table (assuming you have one)
    $name = $_POST['name'];
    $address = $_POST['address'];
    $payment_method = $_POST['payment'];

    // Retrieve cart items for the user
    $cart_query = $conn->prepare("SELECT product_id, quantity FROM carts WHERE user_id = ?");
    $cart_query->bind_param("i", $user_id);
    $cart_query->execute();
    $cart_result = $cart_query->get_result();

    if ($cart_result->num_rows > 0) {
        while ($row = $cart_result->fetch_assoc()) {
            $product_id = $row['product_id'];
            $quantity = $row['quantity'];
            
            // Insert into the 'orders' table (assuming you have it set up)
            $order_query = $conn->prepare("INSERT INTO orders (user_id, product_id, quantity, name, address, payment_method) VALUES (?, ?, ?, ?, ?, ?)");
            $order_query->bind_param("iiisss", $user_id, $product_id, $quantity, $name, $address, $payment_method);
            $order_query->execute();
            $order_query->close();
        }

        // Clear the user's cart after order is placed
        $clear_cart_query = $conn->prepare("DELETE FROM carts WHERE user_id = ?");
        $clear_cart_query->bind_param("i", $user_id);
        $clear_cart_query->execute();
        $clear_cart_query->close();

        echo "<p>Your order has been placed successfully!</p>";
    } else {
        echo "<p>Your cart is empty.</p>";
    }

    $cart_query->close();
}
?>

<div class="container">
    <h1>Checkout</h1>
    <form method="post" action="checkout.php">
        <label for="name">Full Name:</label>
        <input type="text" name="name" required>

        <label for="address">Address:</label>
        <input type="text" name="address" required>

        <label for="payment">Payment Method:</label>
        <select name="payment">
            <option value="cod">Cash on Delivery</option>
        </select>

        <input type="submit" name="checkout" value="Place Order">
    </form>
</div>

<?php include('includes/footer.php'); ?>
