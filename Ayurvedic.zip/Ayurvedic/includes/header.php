<?php
session_start();
$cartCount = isset($_SESSION['cart']) ? array_sum(array_column($_SESSION['cart'], 'quantity')) : 0;
?>

<nav>
    <!-- Other nav links -->
    <a href="cart.php">Cart (<?php echo $cartCount; ?>)</a>
</nav>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/css/style.css"> <!-- Adjust path if necessary -->
    <title>Pet's House</title>
    <style>
        header {
            background-color: #e1f5fe; /* Light blue background */
            padding: 10px 20px;
            border-bottom: 2px solid #0d47a1; /* Darker blue */
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-sizing: border-box;
        }
        body {
            margin: 0;
            padding-top: 80px;
            font-family: Arial, sans-serif;
            background-color: #f0f4f8; /* Slightly off-white for the body */
        }
        .logo {
            flex-shrink: 0;
            padding: 5px;
        }
        .logo img {
            height: 50px;
        }
        .title {
            font-size: 1.5rem;
            color: #0d47a1; /* Dark blue */
            margin-left: 50px;
            font-weight: bold;
            flex-grow: 1;
        }
        nav {
            margin-top: 15px;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }
        nav ul li {
            display: inline;
        }
        nav ul li a {
            text-decoration: none;
            color: #0d47a1; /* Dark blue */
            font-weight: bold;
            padding: 5px 10px;
            transition: all 0.3s;
            background-color: rgba(13, 71, 161, 0.1); /* Light blue */
            border-radius: 4px;
        }
        nav ul li a:hover {
            color: #fff;
            background-color: rgba(13, 71, 161, 0.5); /* Darker blue on hover */
        }
        .logout-btn {
            color: #fff;
            background-color: #d9534f; /* Red for logout button */
            margin-right: 20px;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        .logout-btn:hover {
            background-color: #c9302c; /* Darker red on hover */
        }

        form.d-flex {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 5px;
        }

        .search-inp {
            width: 200px;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 20px;
            font-size: 16px;
            transition: width 0.3s, box-shadow 0.3s;
        }

        .search-inp:focus {
            width: 300px;
            outline: none;
            box-shadow: 0 0 10px rgba(13, 71, 161, 0.2); /* Focus effect with dark blue */
        }

        .btn-search {
            background-color: #0d47a1; /* Dark blue */
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 20px;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s, box-shadow 0.3s;
        }

        .btn-search:hover {
            background-color: #0b3d91; /* Darker blue */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        @media (max-width: 768px) {
            nav ul {
                flex-direction: column;
                align-items: flex-start;
            }
            .title {
                font-size: 1.2rem;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <a href="/Ayurvedic/index.php">
                <img src="./assests/images/logo.jpg" alt="Logo">
            </a>
        </div>
        <div class="title" style="color: #0000ff;">

            <h2>Pet's House</h2>
        </div>
        <nav>
            <ul>
                <li><a href="/Ayurvedic/index.php">Home</a></li>
                <li><a href="/Ayurvedic/Product.php">Products</a></li>
                <li><a href="/Ayurvedic/cart.php">Cart</a></li>
                <li><a href="/Ayurvedic/user/contact.php">Contact</a></li>
                <li><a href="/Ayurvedic/user/about.php">About</a></li>


                <?php if (isset($_SESSION['user'])): ?>
                    <?php $username = $_SESSION['user']; ?>
                    <li>
                        <a href="/Ayurvedic/user/profile.php">Welcome, <?php echo htmlspecialchars($username); ?></a>
                    </li>
                    <li>
                        <a href="/Ayurvedic/user/logout.php" class="logout-btn">Logout</a>
                    </li>
                <?php else: ?>
                    <li><a href="/Ayurvedic/user/login.php">Login</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </header>
</body>
</html>
