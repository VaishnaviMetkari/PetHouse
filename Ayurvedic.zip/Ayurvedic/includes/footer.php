<!-- Footer Section -->
<footer class="footer_section">
<div class="container" style="background-color: #e0f7fa;">

        <div class="footer_content">
            <div class="footer_column">
                <h5>Our Vision</h5>
                <p>
                    At Pet's House, we envision a world where every pet finds a loving home and receives the care, attention, and products they deserve. Our mission is to provide pet owners with high-quality, innovative products that enhance the well-being and happiness of their furry companions.
                </p>
            </div>
            <div class="footer_column">
                <h5>Useful Links</h5>
                <a href="index.php">Home</a>
                <a href="user/about.php">About</a>
                <a href="cart.php">Cart</a>
                <a href="user/contact.php">Contact</a>
            </div>
            <div class="footer_column">
                <!-- Optional image column for any other content -->
                 <img src="assets/images/footer.png">
            </div>
            <div class="footer_column">
                <h5>Follow Us</h5>
                <div class="social_icons">
                    <a href="#"><img src="assets/images/facebook-icon.png" alt="Facebook" class="social-icon"></a>
                    <a href="#"><img src="assets/images/twitter-icon.png" alt="Twitter" class="social-icon"></a>
                    <a href="#"><img src="assets/images/instagram-icon.jpg" alt="Instagram" class="social-icon"></a>
                    <a href="#"><img src="assets/images/youtube-icon.png" alt="YouTube" class="social-icon"></a>
                    <a href="#"><img src="assets/images/linkedin-icon.png" alt="LinkedIn" class="social-icon"></a>
                </div>
            </div>
        </div>
        <div class="footer_bottom">
            <p>
                &copy; 2024 International Society for Technology in Education (ISTE). All rights reserved.
            </p>
        </div>
    </div>
</footer>

<!-- Add this styling to match the layout and text color -->
<style>
    /* Footer Layout */
    .footer_content {
        display: flex;
        justify-content: space-between;
        padding: 40px 0;
        border-top: 1px solid #444;
    }

    .footer_column {
        width: 23%;
        margin-bottom: 40px; /* Increased margin for more space between sections */
    }

    .footer_column h5 {
        margin-bottom: 20px; /* Increased margin for better spacing */
        font-size: 1.2em;
        color: #0000ff; /* Updated text color */
    }

    .footer_column p, .footer_column a {
        color: #0000ff; /* Updated text color */
        font-size: 0.9em;
        line-height: 1.6;
    }

    .footer_column a {
        display: block;
        margin: 5px 0;
        text-decoration: none;
    }

    .footer_column a:hover {
        color: #4CAF50; /* Green on hover */
    }

    .footer_bottom {
        text-align: center;
        padding: 20px 0;
        border-top: 1px solid #444;
        font-size: 0.8em;
        color: #0000ff; /* Updated text color */
    }

    .social_icons {
        display: flex;
        gap: 15px;
        margin-top: 10px;
    }

    .social_icons a {
        text-decoration: none;
    }

    .social-icon {
        width: 30px; /* Adjust size as needed */
        height: 30px; /* Adjust size as needed */
    }

    .social_icons a:hover {
        /* Optional hover effect if desired */
        opacity: 0.7; 
    }
</style>
