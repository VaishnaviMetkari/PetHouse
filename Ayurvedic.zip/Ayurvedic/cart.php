<?php
session_start();
include('includes/db_connect.php');

// Initialize cart if not already initialized
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
}

// Handle adding product to cart
if (isset($_GET['action']) && $_GET['action'] == 'add') {
    $productId = $_GET['id'];
    
    // Fetch product details from the database
    $query = "SELECT * FROM products WHERE id = '$productId'";
    $result = mysqli_query($conn, $query);
    $product = mysqli_fetch_assoc($result);

    // Check if product is already in the cart
    if (isset($_SESSION['cart'][$productId])) {
        // Increase quantity if product is already in the cart
        $_SESSION['cart'][$productId]['quantity'] += 1;
    } else {
        // Add new product to cart
        $_SESSION['cart'][$productId] = array(
            'id' => $product['id'],
            'name' => $product['name'],
            'price' => $product['price'],
            'image' => $product['image'],
            'quantity' => 1
        );
    }

    // Redirect to cart page after adding the product
    header("Location: cart.php");
    exit();
}

// Handle removing a product from the cart
if (isset($_GET['action']) && $_GET['action'] == 'remove') {
    $productId = $_GET['id'];
    unset($_SESSION['cart'][$productId]);
    header("Location: cart.php");
    exit();
}

// Handle displaying the form after Place Order button click
if (isset($_POST['place_order'])) {
    $showForm = true; // Flag to show contact & address form
}

// Handle Pay button click - shows payment form based on selected payment method
if (isset($_POST['submit_details'])) {
    $showPaymentForm = true; // Flag to show payment details form
    $paymentMethod = $_POST['payment_method']; // Store payment method for later use
    // Store user details for later use
    $_SESSION['user_details'] = [
        'full_name' => $_POST['full_name'],
        'email' => $_POST['email'],
        'phone' => $_POST['phone'],
        'address' => $_POST['address'],
        'city' => $_POST['city'],
        'state' => $_POST['state'],
        'postal_code' => $_POST['postal_code']
    ];
}

// Handle Confirm Payment button click
if (isset($_POST['confirm_payment'])) {
    $paymentMethod = $_POST['payment_method']; // Get payment method
    $userDetails = $_SESSION['user_details']; // Get user details

    // Get the current date
    $currentDate = new DateTime();

    // Calculate the estimated delivery date (e.g., 3 days from now)
    $estimatedDeliveryDate = $currentDate->modify('+3 days')->format('Y-m-d');

    // Check if payment method is Cash on Delivery
    if ($paymentMethod == 'cod') {
        // Display order confirmation message
        echo "<h2>Order Confirmed!</h2>";
        echo "<p>Thank you for your order. Your total amount of <strong>{$_POST['total_amount']} INR</strong> will be collected in cash upon delivery.</p>";
        
        // Display estimated delivery date
        echo "<p>Estimated Delivery Date: <strong>{$estimatedDeliveryDate}</strong></p>";
        
        // Display shipping address
        echo "<h3>Shipping Address:</h3>";
        echo "<p>{$userDetails['full_name']}<br>{$userDetails['address']}<br>{$userDetails['city']}, {$userDetails['state']} {$userDetails['postal_code']}<br>Phone: {$userDetails['phone']}</p>";
    }
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Cart</title>
    <style>
        /* General body styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #e0f7fa;
            color: #333;
            margin: 0;
            padding: 0;
        }

        /* Cart container styling */
        .cart-container {
            max-width: 900px;
            margin: 50px auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        h2 {
            text-align: center;
            font-size: 32px;
            color: #0288d1;
            margin-bottom: 20px;
        }

        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding: 15px;
            background-color: #e1f5fe;
            border-radius: 8px;
            box-shadow: 0px 3px 6px rgba(0, 0, 0, 0.1);
        }

        .cart-item img {
            max-width: 100px;
            border-radius: 8px;
        }

        .cart-item-info {
            flex-grow: 1;
            margin-left: 15px;
        }

        .cart-item-info h3 {
            margin: 0;
            font-size: 20px;
            color: #0277bd;
        }

        .cart-item-info p {
            margin: 5px 0;
            font-size: 16px;
        }

        .cart-item-actions {
            display: flex;
            align-items: center;
        }

        .cart-item-actions a {
            margin-left: 10px;
            padding: 8px 12px;
            background-color: #0288d1;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .cart-item-actions a:hover {
            background-color: #0277bd;
        }

        .cart-summary {
            text-align: right;
            margin-top: 20px;
            font-size: 20px;
        }

        .cart-summary h3 {
            color: #01579b;
        }

        .empty-cart {
            text-align: center;
            font-size: 18px;
            color: #0277bd;
        }

        /* Form styling */
        .order-form, .payment-form {
            margin-top: 20px;
            padding: 20px;
            background-color: #f1f8e9;
            border-radius: 10px;
            box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
        }

        .order-form input, .order-form select, .payment-form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .order-form button, .payment-form button {
            padding: 10px 20px;
            background-color: #0288d1;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .order-form button:hover, .payment-form button:hover {
            background-color: #0277bd;
        }

        button[name='place_order']:hover {
            background-color: #0277bd;
        }
    </style>
</head>
<body>
    <div class="cart-container">
        <h2>Your Cart</h2>
        <?php if (empty($_SESSION['cart'])): ?>
            <p class="empty-cart">Your cart is empty.</p>
        <?php else: ?>
            <?php foreach ($_SESSION['cart'] as $item): ?>
                <div class="cart-item">
                    <img src="assets/images/<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>">
                    <div class="cart-item-info">
                        <h3><?php echo $item['name']; ?></h3>
                        <p>Price: <?php echo $item['price']; ?> INR</p>
                        <p>Quantity: <?php echo $item['quantity']; ?></p>
                    </div>
                    <div class="cart-item-actions">
                        <a href="cart.php?action=remove&id=<?php echo $item['id']; ?>">Remove</a>
                    </div>
                </div>
            <?php endforeach; ?>
            <div class="cart-summary">
                <h3>Total: <?php 
                    $total = 0;
                    foreach ($_SESSION['cart'] as $item) {
                        $total += $item['price'] * $item['quantity'];
                    }
                    echo $total;
                ?> INR</h3>
            </div>
            <form method="post" action="cart.php">
                <input type="hidden" name="total_amount" value="<?php echo $total; ?>">
                <button type="submit" name="place_order" style="
                    margin-left: 10px;
                    padding: 8px 12px;
                    background-color: #0288d1; /* Dark sky blue color */
                    color: white;
                    text-decoration: none;
                    border-radius: 5px;
                    transition: background-color 0.3s;
                    border: none;
                    cursor: pointer;">
                    Place Order
                </button>
            </form>
        <?php endif; ?>

        <!-- Contact Information & Address Form -->
        <?php if (isset($showForm) && $showForm): ?>
            <div class="order-form">
                <form method="post" action="cart.php">
                    <h3>Contact Information</h3>
                    <input type="text" name="full_name" placeholder="Full Name" required>
                    <input type="email" name="email" placeholder="Email" required>
                    <input type="text" name="phone" placeholder="Phone" required>
                    <input type="text" name="address" placeholder="Address" required>
                    <input type="text" name="city" placeholder="City" required>
                    <input type="text" name="state" placeholder="State" required>
                    <input type="text" name="postal_code" placeholder="Postal Code" required>
                    <button type="submit" name="submit_details">Continue to Payment</button>
                </form>
            </div>
        <?php endif; ?>

        <!-- Payment Method Selection -->
        <?php if (isset($showPaymentForm) && $showPaymentForm): ?>
            <div class="payment-form">
                <form method="post" action="cart.php">
                    <h3>Select Payment Method</h3>
                    <select name="payment_method" required>
                        <option value="cod">Cash on Delivery</option>
                    </select>
                    <input type="hidden" name="total_amount" value="<?php echo $total; ?>">
                    <button type="submit" name="confirm_payment">Confirm Payment</button>
                </form>
            </div>
        <?php endif; ?>
    </div>

    
</body>
</html>
