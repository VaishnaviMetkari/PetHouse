<?php
include('includes/db_connect.php');
include('includes/header.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Pet's House - Home</title>
    <style>
        /* Basic styles for the home section */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f4f8; /* Light background */
            margin: 0;
            padding: 0;
        }
        .hero {
            background-image: url('assets/images/main-banner.jpg');
            height: 600px;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            color: white;
            text-align: center;
            font-size: 2.5rem;
            padding: 20px;
        }

        .container {
            width: 100%; /* Increase width of the container */
            max-width: 1400px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff; 
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .category, .category2 {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
        }

        .category div, .category2 div {
            text-align: center;
            background-color: #e1f5fe; /* Light blue background for categories */
            border-radius: 8px;
            padding: 20px;
            flex: 1;
            margin: 0 10px;
            transition: transform 0.3s;
        }

        .category div:hover, .category2 div:hover {
            transform: scale(1.05);
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
        }

        .featured-products {
            margin: 20px 0;
        }

        .product-card {
            display: inline-block;
            width: 200px;
            margin: 10px;
            background-color: #e8f5e9; /* Slightly different light color for product cards */
            border-radius: 8px;
            padding: 15px;
            text-align: center;
            transition: transform 0.3s;
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .testimonials {
            background-color: #e0f7fa; /* Light cyan background */
            padding: 20px;
            border-radius: 8px;
            text-align: center;
        }

        .newsletter {
            margin-top: 20px;
            text-align: center;
        }

        .newsletter input[type="email"] {
            padding: 10px;
            width: 300px;
            border-radius: 4px;
            border: 1px solid #ccc;
            margin-right: 10px;
        }

        .newsletter button {
            padding: 10px 15px;
            background-color: #388e3c; /* Dark green for subscribe button */
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .newsletter button:hover {
            background-color: #2e7d32; /* Darker green on hover */
        }

        /* New styles for the blog section */
        .category2 div {
            font-family: 'Verdana'; /* Change font style */
        }

        .category2 h3 {
            font-family: 'Candara', serif; /* Change heading font */
        }
    </style>
</head>
<body>

<div class="hero">
    <h1>Welcome to Pet's House</h1>
    <p>Your one-stop shop for all pet needs!</p>
</div>

<div class="container">
    <h2 class="section-title" style="font-size: 2.5em; text-align: center; color: #333; margin-bottom: 50px;">
        <span class="span" style="color: #0000ff;">Shop by</span> Category
    </h2>
    <div class="category">
        <div>
            <img src="assets/images/dogfood.jpg" alt="dog Food">
            <h3>Dog Food</h3>
            <p>Explore our range of nutritious dog food</p>
        </div>
        <div>
            <img src="assets/images/catfood.jpg" alt="Cat Food">
            <h3>Cat Food</h3>
            <p>Healthy and delicious cat food options</p>
        </div>
        <div>
            <img src="assets/images/fishfood.jpg" alt="fish Food">
            <h3>Fish Supplies</h3>
            <p>Everything you need for your aquatic friends</p>
        </div>
    </div>

    <div class="container2">
        <h2 class="section-title" style="font-size: 2.5em; text-align: center; color: #333; margin-bottom: 50px;">
            <span class="span" style="color: #0000ff;">Our</span> Blogs
        </h2>
        <div class="category2">
            <div>
                <img src="assets/images/blog 1.png" alt="Blog 1">
                <h3>Blog 1</h3>
                <p><b>Choosing the Right Food for Your Pet</b></p>
                <p>Feeding your pet the right nutrition is crucial for their health and happiness. Different pets have different dietary needs based on their age, size, and activity level. Learn how to read pet food labels, understand the benefits of high-quality ingredients.</p>
            </div>
            <div>
                <img src="assets/images/blog 2.png" alt="Blog 2">
                <h3>Blog 2</h3>
                <p><b>Essential Accessories Every Pet Owner Needs</b></p>
                <p>From comfortable beds to interactive toys, the right accessories can enhance your pet's life. Discover our top picks for must-have pet accessories, including grooming tools, collars, leashes, and feeding supplies.</p>
            </div>
            <div>
                <img src="assets/images/Blog 3.png" alt="Blog 3">
                <h3>Blog 3</h3>
                <p><b>How to Switch Your Pet’s Food Safely</b></p>
                <p>Changing your pet’s food can be tricky, but it’s essential for their health. To avoid digestive issues, introduce the new food gradually over a week. Mix it with their current food, slowly increasing the new food's proportion.</p>
            </div>
        </div>

        <div class="testimonials">
            <h2 class="section-title" style="font-size: 2.5em; text-align: center; color: #333; margin-bottom: 50px;">
                <span class="span" style="color: #0000ff;">Customer</span> Reviews
            </h2>
            <p>"Great products and fast delivery!"</p>
            <p>"My pets love their new food!"</p>
            <p>"Fantastic service and support!"</p>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>

</body>
</html>
